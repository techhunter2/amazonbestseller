"""You can set scheduling time
in schd_time variable by default it's set to 06:01 daily."""
schd_time = '06:00'
