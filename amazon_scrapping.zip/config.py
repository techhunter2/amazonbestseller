"""You can set exceution time here and also scheduling time
in schd_time variable by default it's set to 06:01 daily."""
exection_time = 1
schd_time = '06:01'